@echo off
title 9DEVS
python start.py %*
pause
