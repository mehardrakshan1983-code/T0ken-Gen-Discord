import os
import sys
import json
import subprocess
import time
if os.name == "nt":
    os.system("")
P = "\033[38;2;121;3;255m"     
C = "\033[38;2;3;248;252m"     
G = "\033[38;2;68;255;0m"      
Y = "\033[38;2;252;248;3m"     
D = "\033[38;2;92;94;91m"      
W = "\033[97m"                 
RD = "\033[38;2;255;80;80m"    
R = "\033[0m"                  
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")
def clear():
    os.system("cls" if os.name == "nt" else "clear")
def load_config():
    with open(CONFIG_FILE, encoding="utf-8") as f:
        return json.load(f)
def save_config(cfg):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=4)
def banner():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    print(f"""
  {P}┌───────────────────────────────────────────────┐
  │                                               │
  │   █████╗ ██████╗ ███████╗██╗   ██╗███████╗    │
  │  ██╔══██╗██╔══██╗██╔════╝██║   ██║██╔════╝    │
  │  ╚██████║██║  ██║█████╗  ██║   ██║███████╗    │
  │   ╚═══██║██║  ██║██╔══╝  ╚██╗ ██╔╝╚════██║    │
  │   █████╔╝██████╔╝███████╗ ╚████╔╝ ███████║    │
  │   ╚════╝ ╚═════╝ ╚══════╝  ╚═══╝  ╚══════╝    │
  │                                               │
  │  {D}9DEVS v1.0{P}                                   │
  │  {D}Fast · Stealth · Reliable{P}                    │
  │                                               │
  └───────────────────────────────────────────────┘{R}
""")
def main_menu():
    while True:
        clear()
        banner()
        print(f"  {P}┌───────────────────────────────────────────────┐{R}")
        print(f"  {P}│{R}                                               {P}│{R}")
        print(f"  {P}│{R}   {C}[1]{R}  Start Generator                        {P}│{R}")
        print(f"  {P}│{R}   {C}[2]{R}  Settings                               {P}│{R}")
        print(f"  {P}│{R}   {C}[3]{R}  Proxy Checker                          {P}│{R}")
        print(f"  {P}│{R}   {C}[4]{R}  Setup {D}(Install Dependencies){R}           {P}│{R}")
        print(f"  {P}│{R}   {C}[5]{R}  Exit                                   {P}│{R}")
        print(f"  {P}│{R}                                               {P}│{R}")
        print(f"  {P}└───────────────────────────────────────────────┘{R}")
        print()
        choice = input(f"  {P}›{R} Select option: ").strip()
        if choice == "1":   start_generator()
        elif choice == "2": settings_menu()
        elif choice == "3": start_proxy_checker()
        elif choice == "4": setup()
        elif choice == "5": sys.exit(0)
def start_proxy_checker():
    clear()
    subprocess.run([sys.executable, "engine/proxy_checker.py"], cwd=BASE_DIR)
def start_generator():
    clear()
    print(f"\n  {P}┌──────────────────────────────────────────┐{R}")
    print(f"  {P}│{R}  {C}Starting 9DEVS...{R}                        {P}│{R}")
    print(f"  {P}└──────────────────────────────────────────┘{R}\n")
    print(f"  {D}›› Launching Token Generator...{R}")
    time.sleep(1)
    print(f"  {G}✓  Generator starting...{R}\n")
    subprocess.run([sys.executable, "main.py"], cwd=BASE_DIR)
    print(f"\n  {Y}›› Generator stopped. Press Enter to return...{R}")
    input()
def settings_menu():
    while True:
        clear()
        cfg = load_config()
        cap_cfg = cfg.get("9captcha", {})
        mail_cfg = cfg.get("devs_mail", {})
        verif_cfg = cfg.get("verification", {})
        hz = cfg.get("humanizer", {})
        ext_on = cap_cfg.get("extension_solver", True)
        vps_on = cap_cfg.get("req_solver", False)
        solver_mode = []
        if ext_on: solver_mode.append("Extension")
        if vps_on: solver_mode.append("Req")
        solver_str = " + ".join(solver_mode) if solver_mode else "None (auto)"
        print(f"\n  {P}┌──────────────────────────────────────────┐{R}")
        print(f"  {P}│{R}  {C}9DEVS Settings{R}                           {P}│{R}")
        print(f"  {P}├──────────────────────────────────────────┤{R}")
        print(f"  {P}│{R}                                          {P}│{R}")
        print(f"  {P}│{R}   {C}[1]{R}  Threads                              {P}│{R}")
        print(f"  {P}│{R}   {C}[2]{R}  9Captcha API Key                    {P}│{R}")
        print(f"  {P}│{R}   {C}[3]{R}  Mail API Key {D}(CyberTemp){R}            {P}│{R}")
        print(f"  {P}│{R}   {C}[4]{R}  Verification {D}(on/off){R}               {P}│{R}")
        print(f"  {P}│{R}   {C}[5]{R}  Humanizer {D}(on/off){R}                  {P}│{R}")
        print(f"  {P}│{R}   {C}[6]{R}  Solver URL {D}(Endpoint){R}              {P}│{R}")
        print(f"  {P}│{R}   {C}[7]{R}  Open config.json in editor          {P}│{R}")
        print(f"  {P}│{R}   {C}[8]{R}  Solver Mode {D}(Ext/Req){R}              {P}│{R}")
        print(f"  {P}│{R}   {C}[0]{R}  Back                                {P}│{R}")
        print(f"  {P}│{R}                                          {P}│{R}")
        print(f"  {P}└──────────────────────────────────────────┘{R}\n")
        print(f"  {P}│{R} {D}Current:{R}")
        print(f"  {P}│{R}   Threads:        {W}{cfg.get('threads', 1)}{R}")
        print(f"  {P}│{R}   Solver URL:     {W}{cap_cfg.get('url', 'https://9captcha-api.pridesmp.fun')[:20]}...{R}")
        print(f"  {P}│{R}   9Captcha API:   {W}{cap_cfg.get('api_key', 'Not set')[:8]}...{R}")
        print(f"  {P}│{R}   Mail API Key:   {W}{mail_cfg.get('api_key', 'Not set')[:8]}...{R}")
        print(f"  {P}│{R}   Verification:   {W}{verif_cfg.get('enabled', True)}{R}")
        print(f"  {P}│{R}   Humanizer:      {W}{hz.get('enabled', False)}{R}")
        print(f"  {P}│{R}   Solver Mode:    {G if ext_on else RD}Ext:{ext_on}{R} | {G if vps_on else RD}Req:{vps_on}{R}  ({solver_str})")
        print()
        s = input(f"  {P}›{R} Select setting: ").strip()
        if s == "1":
            v = input(f"  {D}›› Thread count: {R}").strip()
            try:
                cfg["threads"] = int(v)
                save_config(cfg)
                print(f"  {G}✓  Threads set to {v}{R}")
            except ValueError:
                print(f"  {Y}!  Invalid number{R}")
            time.sleep(1)
        elif s == "2":
            v = input(f"  {D}›› 9Captcha API key: {R}").strip()
            if "9captcha" not in cfg: cfg["9captcha"] = {}
            cfg["9captcha"]["api_key"] = v
            save_config(cfg)
            print(f"  {G}✓  9Captcha API key updated{R}")
            time.sleep(1)
        elif s == "3":
            v = input(f"  {D}›› Mail API key: {R}").strip()
            if "devs_mail" not in cfg: cfg["devs_mail"] = {}
            cfg["devs_mail"]["api_key"] = v
            save_config(cfg)
            print(f"  {G}✓  Mail API key updated{R}")
            time.sleep(1)
        elif s == "4":
            if "verification" not in cfg: cfg["verification"] = {}
            cfg["verification"]["enabled"] = not cfg["verification"].get("enabled", True)
            save_config(cfg)
            print(f"  {G}✓  Verification set to {cfg['verification']['enabled']}{R}")
            time.sleep(1)
        elif s == "5":
            hz["enabled"] = not hz.get("enabled", False)
            if hz["enabled"]:
                print(f"  {D}  Configure LeakHub Humanizer options:{R}")
                for key in ["avatar", "bio", "pronouns", "display_name", "hypesquad"]:
                    v = input(f"  {D}››   {key}? (true/false, enter=keep): {R}").strip().lower()
                    if v in ("true", "false"):
                        hz[key] = v == "true"
            cfg["humanizer"] = hz
            save_config(cfg)
            print(f"  {G}✓  Humanizer set to {hz['enabled']}{R}")
            time.sleep(1)
        elif s == "6":
            v = input(f"  {D}›› Solver Endpoint URL: {R}").strip()
            if "9captcha" not in cfg: cfg["9captcha"] = {}
            cfg["9captcha"]["url"] = v
            save_config(cfg)
            print(f"  {G}✓  Solver URL updated{R}")
            time.sleep(1)
        elif s == "7":
            if os.name == "nt":
                os.system(f"notepad {CONFIG_FILE}")
            else:
                os.system(f"nano {CONFIG_FILE}")
        elif s == "8":
            print(f"\n  {P}┌── Solver Mode ──────────────────────────┐{R}")
            print(f"  {P}│{R}  {C}[1]{R}  Toggle Extension Solver              {P}│{R}")
            print(f"  {P}│{R}  {C}[2]{R}  Toggle Req Solver                    {P}│{R}")
            print(f"  {P}│{R}  {C}[3]{R}  Enable Both                          {P}│{R}")
            print(f"  {P}│{R}  {C}[0]{R}  Back                                 {P}│{R}")
            print(f"  {P}└──────────────────────────────────────────┘{R}")
            sub = input(f"  {P}›{R} Select: ").strip()
            if "9captcha" not in cfg: cfg["9captcha"] = {}
            if sub == "1":
                current = cfg["9captcha"].get("extension_solver", True)
                cfg["9captcha"]["extension_solver"] = not current
                save_config(cfg)
                print(f"  {G}✓  Extension solver set to {not current}{R}")
            elif sub == "2":
                current = cfg["9captcha"].get("req_solver", False)
                cfg["9captcha"]["req_solver"] = not current
                save_config(cfg)
                print(f"  {G}✓  Req solver set to {not current}{R}")
            elif sub == "3":
                cfg["9captcha"]["extension_solver"] = True
                cfg["9captcha"]["req_solver"] = True
                save_config(cfg)
                print(f"  {G}✓  Both solvers enabled{R}")
            time.sleep(1)
        elif s == "0" or s == "":
            return
def setup():
    clear()
    print(f"\n  {P}┌──────────────────────────────────────────┐{R}")
    print(f"  {P}│{R}  {C}9DEVS Setup{R}                              {P}│{R}")
    print(f"  {P}└──────────────────────────────────────────┘{R}\n")
    print(f"  {D}›› Installing dependencies...{R}\n")
    req_path = os.path.join(BASE_DIR, "requirements.txt")
    os.system(f"pip install -r \"{req_path}\"")
    print(f"\n  {G}✓  Setup complete!{R}\n")
    print(f"  {Y}Press Enter to return...{R}")
    input()
if __name__ == "__main__":
    try:
        main_menu()
    except KeyboardInterrupt:
        print(f"\n  {Y}›› Exiting...{R}")
        sys.exit(0)
