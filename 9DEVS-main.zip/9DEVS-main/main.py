
import hashlib
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional, Dict, Any, List
from pathlib import Path
from io import BytesIO
from urllib.parse import quote
import primp
from colorama import Fore, Style
from PIL import Image
import asyncio
import websockets
from python_socks.async_.asyncio import Proxy
import stealth_requests as requests
from stealth_requests import StealthSession
import base64
import json
import os
import platform
import random
import re
import string
import threading
import time
import uuid
import websocket
import ctypes
import sys
from datetime import datetime
from urllib.parse import urlparse
P = "\033[38;2;121;3;255m"     
C = "\033[38;2;3;248;252m"     
G = "\033[38;2;68;255;0m"      
D = "\033[38;2;92;94;91m"      
R = "\033[0m"                  
class DEVSMailApi:
    BASE_URL = "https://api.cybertemp.xyz"
    def __init__(self, logger=None, forced_domain: str = None, api_key: str = None):
        self.created_emails = {}
        self.logger = logger
        self.forced_domain = forced_domain
        self.api_key = (api_key or os.getenv("CYBERTEMP_API_KEY", "")).strip()
        if not self.api_key:
            self.api_key = self._read_api_key_from_config()
        self.headers = {"X-API-KEY": self.api_key} if self.api_key else {}
    def _build_proxies(self, proxy: str = None):
        if proxy and "://" not in proxy:
            proxy = f"http://{proxy}"
        return {"http": proxy, "https": proxy} if proxy else None
    def _log(self, message: str):
        pass
    def _read_api_key_from_config(self):
        try:
            with open("config.json", "r", encoding="utf-8") as f:
                cfg = json.load(f)
            return (cfg.get("devs_mail", {}).get("api_key") or "").strip()
        except Exception:
            return ""
    def get_domains(self):
        try:
            resp = requests.get(f"{self.BASE_URL}/getDomains", params={"type": "discord"}, headers=self.headers, timeout=10)
            if resp.status_code == 200:
                data = resp.json()
                if isinstance(data, dict) and "domains" in data:
                    domains_list = data["domains"]
                elif isinstance(data, list):
                    domains_list = data
                else:
                    return []
                return [d.get("domain", d) if isinstance(d, dict) else d for d in domains_list]
        except:
            pass
        return []
    def create_account(self, email: str = None, password: str = None, proxy: str = None):
        if email and '@' in email:
            created_email = email
        elif self.forced_domain:
            local = ''.join(random.choices(string.ascii_lowercase + string.digits, k=10))
            created_email = f"{local}@{self.forced_domain}"
        else:
            domains = self.get_domains()
            if not domains:
                domains = ["randommail.com"] 
            target_domain = random.choice(domains)
            username = ''.join(random.choices(string.ascii_lowercase + string.digits, k=10))
            created_email = f"{username}@{target_domain}"
        if not created_email:
            self._log("DEVSMail could not create an email")
            return None
        self.created_emails[created_email] = password or ""
        self._log(f"Prepared email: {created_email}")
        return created_email
    def get_verify_url(self, email: str, poll_interval: int = 3, timeout: int = 120, proxy: str = None):
        start_time = time.time()
        used_message_ids = set()
        while time.time() - start_time < timeout:
            try:
                resp = requests.get(f"{self.BASE_URL}/getMail", params={"email": email}, headers=self.headers, timeout=10)
                if resp.status_code == 200:
                    messages = resp.json()
                    if isinstance(messages, list) and messages:
                        for msg in messages:
                            msg_id = msg.get("id")
                            if msg_id in used_message_ids:
                                continue
                            subject = msg.get("subject", "")
                            if "discord" in subject.lower() or "verify" in subject.lower() or "verif" in subject.lower():
                                html_body = msg.get("html", "") or msg.get("text", "") or ""
                                text_body = msg.get("text", "") or ""
                                combined = html_body + text_body
                                all_links = re.findall(r'https?://[^\s"\'<>]+', combined)
                                target_links = [l for l in all_links if ("discord.com" in l or "click.discord.com" in l) and "support." not in l and "blog." not in l]
                                if target_links:
                                    url = None
                                    if len(target_links) >= 2:
                                        second_url = target_links[1]
                                        if "verify" in second_url.lower() or "token=" in second_url.lower() or "click.discord.com" in second_url:
                                            url = second_url
                                    if not url:
                                        url = max(target_links, key=len)
                                    if "click.discord.com" in url:
                                        resolved = self._resolve_url(url, proxy=proxy)
                                        if resolved:
                                            return resolved
                                    return url
                                used_message_ids.add(msg_id)
            except Exception as e:
                self._log(f"Error reading inbox: {e}")
            time.sleep(poll_interval)
        self._log(f"Timeout waiting for verify URL in {email}")
        return None
    def _resolve_url(self, url: str, proxy: str = None) -> str:
        proxies = self._build_proxies(proxy)
        try:
            resp = requests.head(url, allow_redirects=True, timeout=10, proxies=proxies)
            final_url = resp.url
            if "discord.com/verify" in final_url:
                return final_url
        except Exception:
            pass
        return None
class Solver:
    VPS_URL  = "https://9captcha-api.pridesmp.fun"                
    UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'
    def __init__(self, url, sitekey, rqdata="", user_agent="", proxy=None, api_key=""):
        self.url        = url
        self.sitekey    = sitekey
        self.rqdata     = rqdata
        self.user_agent = user_agent
        self.proxy      = proxy
        self.api_key    = api_key
        cap_cfg = config.get("9captcha", {})
        self.use_extension = cap_cfg.get("extension_solver", True)
        self.use_vps       = cap_cfg.get("req_solver", False)
    def _format_proxy(self):
        if self.proxy:
            return self.proxy
        return ""
    def _solve_extension(self, timeout=90):
        
        try:
            from engine.extension_browser import get_browser
            browser = get_browser()
            _file_log("[EXT] Solving via local browser + extension")
            token = browser.solve(
                sitekey=self.sitekey,
                url=self.url,
                rqdata=self.rqdata,
                user_agent=self.user_agent,
                timeout=timeout,
            )
            if token:
                return token, {}
            _file_log("[EXT] Extension solver returned no token")
            return None, None
        except ImportError:
            _file_log("[EXT] extension_browser.py not found or truedriver not installed")
            return None, None
        except Exception as e:
            _file_log(f"[EXT] Error: {e}")
            return None, None
    def _solve_vps(self, timeout=120, poll_interval=2):
        
        import urllib.request, urllib.error, json
        payload = {
            "key": self.api_key,
            "type": "hcaptcha_basic",
            "data": {
                "sitekey": self.sitekey,
                "siteurl": self.url,
                "proxy": self._format_proxy(),
                "rqdata": self.rqdata,
                "useragent": self.user_agent
            }
        }
        req = urllib.request.Request(
            f"{self.VPS_URL}/captcha/api/create_task",
            data=json.dumps(payload).encode('utf-8'),
            headers={'Content-Type': 'application/json', 'User-Agent': self.UA}
        )
        try:
            resp = urllib.request.urlopen(req, timeout=30)
            resp_text = resp.read().decode('utf-8')
            resp_status = resp.getcode()
        except urllib.error.HTTPError as e:
            resp_status = e.code
            resp_text = e.read().decode('utf-8')
        if resp_status != 200:
            _file_log(f"[VPS] Server refused with HTTP {resp_status}")
            return None, None
        data = json.loads(resp_text)
        tid = data.get("task_id")
        if not tid:
            _file_log("[VPS] Missing Task ID")
            return None, None
        start_time = time.time()
        while time.time() - start_time < timeout:
            time.sleep(poll_interval)
            try:
                req2 = urllib.request.Request(
                    f"{self.VPS_URL}/captcha/api/get_result/{tid}?key={self.api_key}",
                    headers={'User-Agent': self.UA}
                )
                r2 = urllib.request.urlopen(req2, timeout=10)
                if r2.getcode() == 200:
                    d = json.loads(r2.read().decode('utf-8'))
                    status = d.get("status")
                    if status == "solved":
                        return d.get("solution"), {}
                    if status == "error":
                        _file_log(f"[VPS] Solver error: {d.get('error')}")
                        return None, None
            except Exception as e:
                _file_log(f"[VPS] Polling error: {e}")
        _file_log(f"[VPS] Timeout after {timeout}s for task {tid}")
        return None, None
    def solve(self, timeout=120, poll_interval=2):
        _file_log(f"Using {self._format_proxy()} {'(our IP)' if not self.proxy else '(proxy)'}")
        _file_log(f"Solver config: extension={self.use_extension}, vps={self.use_vps}")
        if self.use_extension:
            _file_log("[EXT] Using extension solver (local browser, VPS backend)")
            try:
                result = self._solve_extension(timeout)
                if result[0]:
                    return result
                _file_log("[EXT] Failed")
            except Exception as e:
                _file_log(f"[EXT] Error: {e}")
            if self.use_vps:
                _file_log("[VPS] Falling back to VPS solver")
                try:
                    return self._solve_vps(timeout, poll_interval)
                except Exception as e:
                    _file_log(f"[VPS] Error: {e}")
                    return None, None
            return None, None
        if self.use_vps:
            _file_log("[REQ] Using Req solver (request mode)")
            try:
                return self._solve_vps(timeout, poll_interval)
            except Exception as e:
                _file_log(f"[VPS] Error: {e}")
                return None, None
        _file_log("[WARN] No solver enabled! Set extension_solver or req_solver in config.")
        return None, None
config = {}
try:
    with open(os.path.join(os.path.dirname(__file__), "config.json"), "r") as f:
        config = json.load(f)
except Exception as e:
    print(f"Error loading config.json: {e}")
mail_api = DEVSMailApi(logger=print, api_key=config.get("devs_mail", {}).get("api_key"))
verification_enabled = config.get("verification", {}).get("enabled", True)
_logs_enabled = config.get("logs", False)
def _file_log(msg):
    if not _logs_enabled:
        return
    try:
        with open(os.path.join(os.path.dirname(__file__), "logs.txt"), "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}\n")
    except Exception:
        pass
gen_count = 0
gen_lock = threading.Lock()
stats_lock = threading.Lock()
stats = {
    'generated': 0,
    'verified': 0,
    'captcha_failed': 0,
    'captcha_solved': 0,
    'locked': 0,
    'valid': 0,
    'total': 0
}
class ProxyManager:
    def __init__(self, file_path="input/proxies.txt"):
        self.file_path = file_path
        self.lock = threading.Lock()
    def pop_top(self):
        with self.lock:
            if not os.path.exists(self.file_path):
                return None
            try:
                with open(self.file_path, "r", encoding="utf-8") as f:
                    lines = [line for line in f if line.strip()]
                if not lines:
                    return None
                proxy = lines.pop(0).strip()
                with open(self.file_path, "w", encoding="utf-8") as f:
                    for line in lines:
                        if not line.endswith('\n'):
                            line += '\n'
                        f.write(line)
                user_pass = ""
                host_port = ""
                if "@" in proxy:
                    user_pass, host_port = proxy.split("@", 1)
                else:
                    host_port = proxy
                if "dataimpulse" in host_port.lower() and user_pass:
                    if ":" in user_pass:
                        user, pwd = user_pass.split(":", 1)
                        if "__session" not in user:
                            sess_id = uuid.uuid4().hex[:8]
                            user_pass = f"{user}__session_{sess_id}:{pwd}"
                import socket
                if ":" in host_port:
                    host, port = host_port.rsplit(":", 1)
                    try:
                        resolved_ip = socket.gethostbyname(host)
                        host_port = f"{resolved_ip}:{port}"
                    except Exception:
                        pass
                if user_pass:
                    proxy = f"{user_pass}@{host_port}"
                else:
                    proxy = host_port
                return proxy
            except Exception:
                return None
proxy_manager = ProxyManager()
from colorama import Fore, Style, init
from pystyle import Colors, Colorate, Center, Anime, System
init(autoreset=True)
class Log:
    lock = threading.Lock()
    @staticmethod
    def _log(label, text, color=R):
        with Log.lock:
            if "TOKEN" in label or "GENERATED" in label or "VERIFIED" in label:
                print(f"{P}│{R} {G}TOKEN{R}   {D}»{R} {D}{text}{R}")
            else:
                print(f"{P}│{R} {P}9DEVS    {R} {D}»{R} {color if color != R else D}{text}{R}")
    @staticmethod
    def proxy_header(num, proxy):
        if not proxy:
            return
        censor = config.get("censor", True)
        if censor:
            if '@' in proxy:
                auth, hostport = proxy.rsplit('@', 1)
                if ':' in auth:
                    user, pwd = auth.split(':', 1)
                    censored_user = user[:6] + '***'
                    censored_pwd = '****'
                    censored_proxy = f"{censored_user}:{censored_pwd}@{hostport}"
                else:
                    censored_proxy = auth[:6] + '***@' + hostport
            else:
                censored_proxy = proxy[:10] + '***'
            Log._log("9DEVS", f"Proxy {censored_proxy}", Fore.MAGENTA)
        else:
            Log._log("9DEVS", f"Proxy {proxy}", Fore.MAGENTA)
    @staticmethod
    def generated(token):
        with Log.lock:
            parts = token.split(".")
            if len(parts) == 3:
                censored_token = f"{parts[0][:6]}******.{parts[1]}.*******{parts[2][-6:]}"
            else:
                censored_token = token[:15] + "******"
            print(f"{P}│{R} {G}TOKEN{R}   {D}»{R} {D}Generated {R}{G}{censored_token}{R}")
        with stats_lock:
            stats['generated'] += 1
            stats['total'] += 1
    @staticmethod
    def captcha_solved(time_n, token=""):
        token_str = f" &Token: {token[:45]}..." if token else ""
        Log._log("9DEVS", f"Captcha Solved in {time_n:.1f}s{token_str}", Fore.CYAN)
        with stats_lock:
            stats['captcha_solved'] += 1
    @staticmethod
    def solving(email):
        Log._log("9DEVS", "Solving Captcha...", Fore.YELLOW)
    @staticmethod
    def captcha_failed():
        Log._log("DEVS", "Captcha failed", Fore.RED)
        with stats_lock:
            stats['captcha_failed'] += 1
            stats['total'] += 1
    @staticmethod
    def status(status_text):
        Log._log("DEVS", status_text, Fore.MAGENTA)
    @staticmethod
    def error(text):
        Log._log("ERROR", text, Fore.RED)
    @staticmethod
    def waiting(text):
        Log._log("DEVS", text, Fore.YELLOW)
    @staticmethod
    def verified(token):
        with Log.lock:
            parts = token.split(".")
            if len(parts) == 3:
                censored_token = f"{parts[0][:6]}******.{parts[1]}.*******{parts[2][-6:]}"
            else:
                censored_token = token[:15] + "******"
            print(f"{P}│{R} {G}TOKEN{R}   {D}»{R} {D}Verified {R}{G}{censored_token}{R}")
        with stats_lock:
            stats['verified'] += 1
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.225 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.95 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_6_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
]
_FIRST_NAMES = ['alex', 'sam', 'jay', 'riley', 'max', 'charlie', 'taylor', 'jordan', 'casey', 'drew',
                'blake', 'morgan', 'quinn', 'avery', 'peyton', 'sage', 'river', 'eden', 'rowan', 'lee',
                'kai', 'sky', 'rain', 'finn', 'ash', 'nova', 'zion', 'remy', 'lane', 'oak']
_ADJECTIVES = ['cool', 'dark', 'wild', 'fast', 'chill', 'epic', 'real', 'true', 'fire', 'ice',
               'neon', 'void', 'zen', 'pro', 'ace', 'rad', 'dope', 'lit', 'raw', 'hype']
def _random_username() -> str:
    
    patterns = [
        lambda: random.choice(_FIRST_NAMES) + str(random.randint(1, 9999)),
        lambda: random.choice(_FIRST_NAMES) + '_' + random.choice(_ADJECTIVES),
        lambda: random.choice(_ADJECTIVES) + random.choice(_FIRST_NAMES) + str(random.randint(10, 99)),
        lambda: random.choice(_FIRST_NAMES) + random.choice(_FIRST_NAMES) + str(random.randint(1, 999)),
        lambda: random.choice(_FIRST_NAMES) + '.' + str(random.randint(100, 9999)),
    ]
    return random.choice(patterns)()
def _random_password() -> str:
    
    base = ''.join(random.choices(string.ascii_letters, k=random.randint(6, 10)))
    digits = ''.join(random.choices(string.digits, k=random.randint(2, 4)))
    special = random.choice('!@#$%&*')
    pwd = base + digits + special
    return pwd
def _random_dob() -> str:
    
    year = random.randint(1994, 2006)
    month = random.randint(1, 12)
    day = random.randint(1, 28)  
    return f"{year}-{month:02d}-{day:02d}"
def get_build_number(proxy=None):
    try:
        sess = StealthSession()
        if proxy:
            proxy_url = f"http://{proxy}" if "://" not in proxy else proxy
            sess.proxies = {"http": proxy_url, "https": proxy_url}
        page = sess.get("https://discord.com/app").text
        assets = re.findall(r'src="/assets/([^"]+)"', page)
        for asset in reversed(assets):
            js = sess.get(f"https://discord.com/assets/{asset}").text
            if "buildNumber:" in js:
                return int(js.split('buildNumber:"')[1].split('"')[0]) 
    except Exception:
        pass
    return 502645
def build_super_properties(build_number, user_agent, chrome_version):
    payload = {
        "os": "Windows",
        "browser": "Chrome",
        "device": "",
        "system_locale": "en-US",
        "browser_user_agent": user_agent,
        "browser_version": f"{chrome_version}.0.0.0",
        "os_version": platform.release(),
        "referrer": "https://discord.com/",
        "referring_domain": "discord.com",
        "referrer_current": "",
        "referring_domain_current": "",
        "release_channel": "stable",
        "client_build_number": build_number,
        "client_event_source": None,
        "has_client_mods": False,
        "client_launch_id": str(uuid.uuid4()),
        "launch_signature": str(uuid.uuid4()),
        "client_heartbeat_session_id": str(uuid.uuid4()),
        "client_app_state": "focused",
    }
    raw = json.dumps(payload, separators=(",", ":")).encode()
    return base64.b64encode(raw).decode()
def acquire_discord_cookies(session):
    session.get("https://discord.com")
    cookies = session.cookies.get_dict()
    dcfduid = cookies.get("__dcfduid")
    sdcfduid = cookies.get("__sdcfduid")
    return dcfduid, sdcfduid
def fetch_discord_fingerprint(session, dcfduid, sdcfduid, user_agent, chrome_version):
    headers = {
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "en-US,en;q=0.9",
        "cookie": f"__dcfduid={dcfduid}; __sdcfduid={sdcfduid};",
        "sec-ch-ua": f'"Chromium";v="{chrome_version}", "Google Chrome";v="{chrome_version}", "Not-A.Brand";v="99"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "none",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        "user-agent": user_agent
    }
    session.headers = headers
    data = session.get("https://discord.com/api/v9/experiments")
    return data.json()["fingerprint"]
def build_headers(fingerprint, super_props, user_agent, chrome_version):
    return {
        "accept": "*/*",
        "accept-encoding": "gzip, deflate, br, zstd",
        "accept-language": "en-US,en;q=0.9",
        "content-type": "application/json",
        "origin": "https://discord.com",
        "referer": "https://discord.com/",
        "priority": "u=1, i",
        "sec-ch-ua": f'"Chromium";v="{chrome_version}", "Google Chrome";v="{chrome_version}", "Not-A.Brand";v="99"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "user-agent": user_agent,
        "x-debug-options": "bugReporterEnabled",
        "x-discord-locale": "en-US",
        "x-discord-timezone": "America/Los_Angeles",
        "x-fingerprint": fingerprint,
        "x-super-properties": super_props,
    }
def verify_token_integrity(session):
    try:
        r = session.get("https://discord.com/api/v9/users/@me")
        if r.status_code != 200:
            return "invalid"
        r2 = session.get("https://discord.com/api/v9/users/@me/settings")
        if r2.status_code == 200:
            return "Valid"
        elif r2.status_code == 403:
            return "locked"
    except Exception:
        pass
    return "invalid"
def export_credential(email, password, token, token_status, is_verified=False, is_humanized=False):
    os.makedirs("output", exist_ok=True)
    status_lower = token_status.lower() if token_status else ""
    if "locked" in status_lower:
        filename = "output/locked.txt"
    elif "invalid" in status_lower:
        filename = "output/invalid.txt"
    elif is_humanized:
        filename = "output/humanised.txt"
    elif is_verified:
        filename = "output/email_verified.txt"
    else:
        filename = "output/tokens.txt"
    with open(filename, "a", encoding="utf-8") as f:
        f.write(f"{email}:{password}:{token}\n")
class WebSocketClientKeepAlive:
    
    def __init__(self, token):
        self.token = token
        self._stop = threading.Event()
        self._thread = None
    def start(self):
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
    def stop(self):
        self._stop.set()
    def _run(self):
        try:
            ws = websocket.WebSocket()
            ws.settimeout(10)
            ws.connect("wss://gateway.discord.gg/?v=9&encoding=json")
            hello = json.loads(ws.recv())
            heartbeat_interval = hello["d"]["heartbeat_interval"] / 1000
            identify = {
                "op": 2,
                "d": {
                    "token": self.token,
                    "properties": {"$os": "Windows"},
                },
            }
            ws.send(json.dumps(identify))
            ready = False
            for _ in range(10):
                resp = json.loads(ws.recv())
                if resp.get("t") == "READY":
                    ready = True
                    break
                if resp.get("op") == 9:  
                    ws.close()
                    return
            if not ready:
                ws.close()
                return
            while not self._stop.is_set():
                ws.send(json.dumps({"op": 1, "d": None}))
                self._stop.wait(heartbeat_interval)
            ws.close()
        except Exception:
            pass
def process_hcaptcha(sitekey, rqdata, user_agent, proxy=None):
    solver_key = config.get("9captcha", {}).get("api_key", "")
    solver = Solver(
        url="https://discord.com/register",
        sitekey=sitekey,
        rqdata=rqdata,
        user_agent=user_agent,
        proxy=proxy,
        api_key=solver_key
    )
    return solver.solve()
def generate_9DEVS_token(email, username, password, proxy=None, current_num=1):
    Log.proxy_header(current_num, proxy)
    Log.status(f"Got User -> {username}")
    Log.status(f"Got Pass -> {password}")
    masked_mail = f"{email[:4]}***@{email.split('@')[1]}" if '@' in email else email
    Log.status(f"Got Mail -> {masked_mail}")
    session = StealthSession()
    if proxy:
        proxy_url = f"http://{proxy}" if "://" not in proxy else proxy
        session.proxies = {
            "http": proxy_url,
            "https": proxy_url
        }
    user_agent = random.choice(USER_AGENTS)
    chrome_version_match = re.search(r"Chrome/(\d+)", user_agent)
    chrome_version = int(chrome_version_match.group(1)) if chrome_version_match else 121
    try:
        dcfduid, sdcfduid = acquire_discord_cookies(session)
        fingerprint = fetch_discord_fingerprint(session, dcfduid, sdcfduid, user_agent, chrome_version)
    except Exception as e:
        Log.error(f"fingerprint failed: {e}")
        if "timeout" in str(e).lower() or "(28)" in str(e):
            print(f"\n  {Fore.RED}⚠ CRITICAL: Proxy connection timed out. Discord may be blocking your proxies.{Style.RESET_ALL}")
            print(f"  {Fore.YELLOW}  ›› Please run the Proxy Checker from the 9DEVS Start Menu to filter dead/blocked proxies.{Style.RESET_ALL}\n")
            os._exit(1)
        return
    build_num = get_build_number(proxy)
    super_props = build_super_properties(build_num, user_agent, chrome_version)
    headers = build_headers(fingerprint, super_props, user_agent, chrome_version)
    session.headers.update(headers)
    time.sleep(random.uniform(2, 5))
    dob = _random_dob()
    Log.status(f"Got DOB -> {dob}")
    register_payload = {
        "fingerprint": fingerprint,
        "email": email,
        "username": username,
        "password": password,
        "date_of_birth": dob,
        "consent": True,
    }
    Log.status("Creating Acc..")
    res = session.post("https://discord.com/api/v9/auth/register", json=register_payload)
    start_time = time.time()
    res_json = res.json()
    if res.status_code == 429:
        retry_after = res_json.get("retry_after", 60)
        Log.waiting(f"rate limited, waiting {retry_after:.0f}s...")
        time.sleep(retry_after + 1)
        res = session.post("https://discord.com/api/v9/auth/register", json=register_payload)
        res_json = res.json()
    captcha_sitekey = res_json.get("captcha_sitekey")
    captcha_rqdata = res_json.get("captcha_rqdata")
    captcha_rqtoken = res_json.get("captcha_rqtoken")
    captcha_session_id = res_json.get("captcha_session_id")
    if not captcha_sitekey or not captcha_rqdata:
        Log.error("No captcha challenge received")
        return
    Log.solving(email)
    captcha_start = time.time()
    cap_token, cookies = process_hcaptcha(captcha_sitekey, captcha_rqdata, user_agent, proxy)
    if not cap_token:
        Log.captcha_failed()
        return
    if cookies:
        for k, v in cookies.items():
            session.cookies.set(k, v)
    solve_time = time.time() - captcha_start
    Log.captcha_solved(solve_time, cap_token)
    session.headers.update({
        "x-captcha-key": cap_token,
        "x-captcha-rqtoken": captcha_rqtoken,
        "x-captcha-session-id": captcha_session_id,
    })
    response = None
    for attempt in range(3):
        try:
            response = session.post("https://discord.com/api/v9/auth/register", json=register_payload)
            break
        except Exception:
            if attempt < 2:
                time.sleep(1)
            else:
                return
    try:
        raw_text = response.text
    except Exception as e:
        Log.error(f"Failed to read raw response: {e}")
    try:
        res_data = response.json()
    except Exception:
        Log.error("Response is not valid JSON")
        return
    if 'token' not in res_data:
        Log.error(f"no token, raw response: {res_data}")
        return
    auth_token = res_data['token']
    for h in ["x-captcha-key", "x-captcha-rqtoken", "x-captcha-session-id"]:
        session.headers.pop(h, None)
    session.headers.update({"authorization": auth_token})
    Log.status("Token Received...")
    onliner = WebSocketClientKeepAlive(auth_token)
    onliner.start()
    if not verification_enabled:
        pre_verify_status = verify_token_integrity(session)
        is_humanized = False
        if config.get("humanizer", {}).get("enabled", False) and pre_verify_status.lower() == "valid":
            Log.status("starting humanizer")
            try:
                name_list = load_file_lines(NAMES_FILE)
                bio_list = load_file_lines(BIOS_FILE)
                pronouns_list = load_file_lines(PRONOUNS_FILE)
                av_files = load_avatar_files()
                hz = Humanizer(auth_token, proxy)
                success = hz.process(name_list, bio_list, pronouns_list, av_files, load_avatar_as_base64)
                if success:
                    hz_cfg = config.get("humanizer", {})
                    fields = []
                    if hz_cfg.get("bio"): fields.append(f"Bio {Fore.GREEN}✓{Style.RESET_ALL}{Fore.MAGENTA}")
                    if hz_cfg.get("pronouns"): fields.append(f"Pronouns {Fore.GREEN}✓{Style.RESET_ALL}{Fore.MAGENTA}")
                    if hz_cfg.get("hypesquad"): fields.append(f"HypeSquad {Fore.GREEN}✓{Style.RESET_ALL}{Fore.MAGENTA}")
                    if hz_cfg.get("avatar"): fields.append(f"Avatar {Fore.GREEN}✓{Style.RESET_ALL}{Fore.MAGENTA}")
                    if hz_cfg.get("display_name"): fields.append(f"Name {Fore.GREEN}✓{Style.RESET_ALL}{Fore.MAGENTA}")
                    hz_str = " ".join(fields)
                    Log.status(f"humanized {hz_str}")
                    is_humanized = True
            except Exception as e:
                Log.error(f"humaniser module failed: {e}")
        export_credential(email, password, auth_token, pre_verify_status, is_verified=False, is_humanized=is_humanized)
        onliner.stop()
        return
    Log.waiting("waiting for verification email...")
    verify_url = mail_api.get_verify_url(email, 3, 180, proxy)
    if not verify_url:
        Log.error("verification email never arrived — saving as-is")
        token_status = verify_token_integrity(session)
        Log.status(f"Token status: {token_status.upper()}")
        export_credential(email, password, auth_token, token_status)
        onliner.stop()
        return
    Log.status("Got verify URL...")
    try:
        click_headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9',
            'sec-ch-ua': f'"Chromium";v="{chrome_version}", "Google Chrome";v="{chrome_version}", "Not-A.Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': user_agent,
        }
        mail_token = None
        if "token=" in verify_url:
            mail_token = verify_url.split("token=")[-1].split("&")[0]
        if not mail_token:
            location = ""
            r1 = session.get(verify_url, headers=click_headers, allow_redirects=False)
            location = r1.headers.get("Location", "")
            if location:
                fragment = urlparse(location).fragment
                if fragment and "token=" in fragment:
                    mail_token = fragment.split("token=")[-1].split("&")[0]
            if not mail_token and location:
                r2 = session.get(location, headers=click_headers, allow_redirects=False)
                location2 = r2.headers.get("Location", "")
                if location2:
                    fragment2 = urlparse(location2).fragment
                    if fragment2 and "token=" in fragment2:
                        mail_token = fragment2.split("token=")[-1].split("&")[0]
        if not mail_token:
            token_status = verify_token_integrity(session)
            export_credential(email, password, auth_token, token_status)
            onliner.stop()
            return
    except Exception:
        token_status = verify_token_integrity(session)
        export_credential(email, password, auth_token, token_status)
        onliner.stop()
        return
    for h in ["x-captcha-key", "x-captcha-rqtoken", "x-captcha-session-id"]:
        session.headers.pop(h, None)
    time.sleep(random.uniform(1, 3))
    verify_res = session.post(
        "https://discord.com/api/v9/auth/verify",
        json={"token": mail_token}
    )
    verify_json = verify_res.json()
    if verify_json.get("captcha_sitekey"):
        Log.solving(email)
        verify_start = time.time()
        verify_cap_token, verify_cookies = process_hcaptcha(
            verify_json["captcha_sitekey"],
            verify_json.get("captcha_rqdata", ""),
            user_agent,
            proxy
        )
        if not verify_cap_token:
            Log.captcha_failed()
            token_status = verify_token_integrity(session)
            export_credential(email, password, auth_token, token_status)
            onliner.stop()
            return
        verify_solve_time = time.time() - verify_start
        Log.captcha_solved(verify_solve_time, verify_cap_token)
        if verify_cookies:
            for k, v in verify_cookies.items():
                session.cookies.set(k, v)
        session.headers.update({
            "x-captcha-key": verify_cap_token,
            "x-captcha-rqtoken": verify_json.get("captcha_rqtoken", ""),
            "x-captcha-session-id": verify_json.get("captcha_session_id", ""),
        })
        verify_res = session.post(
            "https://discord.com/api/v9/auth/verify",
            json={"token": mail_token}
        )
        verify_json = verify_res.json()
    new_token = verify_json.get("token")
    if new_token:
        auth_token = new_token
        session.headers.update({"authorization": auth_token})
        Log.verified(auth_token)
    else:
        Log.error(f"Verification response had no token: {str(verify_json)[:200]}")
    for h in ["x-captcha-key", "x-captcha-rqtoken", "x-captcha-session-id"]:
        session.headers.pop(h, None)
    token_status = verify_token_integrity(session)
    Log.status(f"Final status: {token_status.upper()}")
    is_humanized = False
    if config.get("humanizer", {}).get("enabled", False) and token_status.lower() == "valid":
        Log.status("starting humanizer")
        try:
            name_list = load_file_lines(NAMES_FILE)
            bio_list = load_file_lines(BIOS_FILE)
            pronouns_list = load_file_lines(PRONOUNS_FILE)
            av_files = load_avatar_files()
            hz = Humanizer(auth_token, proxy)
            success = hz.process(name_list, bio_list, pronouns_list, av_files, load_avatar_as_base64)
            if success:
                hz_cfg = config.get("humanizer", {})
                fields = []
                if hz_cfg.get("bio"): fields.append(f"Bio {Fore.GREEN}✓{Style.RESET_ALL}{Fore.MAGENTA}")
                if hz_cfg.get("pronouns"): fields.append(f"Pronouns {Fore.GREEN}✓{Style.RESET_ALL}{Fore.MAGENTA}")
                if hz_cfg.get("hypesquad"): fields.append(f"HypeSquad {Fore.GREEN}✓{Style.RESET_ALL}{Fore.MAGENTA}")
                if hz_cfg.get("avatar"): fields.append(f"Avatar {Fore.GREEN}✓{Style.RESET_ALL}{Fore.MAGENTA}")
                if hz_cfg.get("display_name"): fields.append(f"Name {Fore.GREEN}✓{Style.RESET_ALL}{Fore.MAGENTA}")
                hz_str = " ".join(fields)
                Log.status(f"humanized {hz_str}")
                is_humanized = True
        except Exception as e:
            Log.error(f"humaniser module failed: {e}")
    export_credential(email, password, auth_token, token_status, is_verified=True, is_humanized=is_humanized)
    onliner.stop()
    pass
from pathlib import Path
SCRIPT_DIR = Path(__file__).resolve().parent
_async_loop = asyncio.new_event_loop()
_async_loop_thread = threading.Thread(target=_async_loop.run_forever, daemon=True)
_async_loop_thread.start()
SCRIPT_DIR = Path(__file__).parent
DATA_DIR = SCRIPT_DIR / "engine" / "data"
INPUT_DIR = SCRIPT_DIR / "engine" / "input"
AVATARS_DIR = SCRIPT_DIR / "engine" / "avatar"
BANNERS_DIR = SCRIPT_DIR / "engine" / "banners"
TOKENS_FILE = INPUT_DIR / "tokens.txt"
PROXIES_FILE = INPUT_DIR / "proxies.txt"
BIOS_FILE = DATA_DIR / "bios.txt"
NAMES_FILE = DATA_DIR / "names.txt"
PRONOUNS_FILE = DATA_DIR / "pronouns.txt"
SUCCESS_FILE = INPUT_DIR / "success.txt"
FAILED_FILE = INPUT_DIR / "failed.txt"
hz_config = config.get("humanizer", {})
MAX_THREADS = hz_config.get("max_threads", 3)
AVATAR_DIMENSION = hz_config.get("avatar_dimension", 256)
MAX_AVATAR_CACHE = hz_config.get("max_avatar_cache", 100)
UPDATE_DISPLAY_NAME = hz_config.get("display_name", True)
UPDATE_BIO = hz_config.get("bio", True)
UPDATE_PRONOUNS = hz_config.get("pronouns", True)
UPDATE_AVATAR = hz_config.get("avatar", True)
UPDATE_HYPESQUAD = hz_config.get("hypesquad", True)
RETRY_LIMIT = hz_config.get("retries", 3)
HYPESQUAD_HOUSES = {
    1: "Bravery",
    2: "Brilliance",
    3: "Balance"
}
DISCORD_API = "https://discord.com/api/v9"
DISCORD_GATEWAY = "wss://gateway.discord.gg/?v=9&encoding=json"
FALLBACK_BUILD_NUMBER = 519006
DISCORD_CLIENT_VERSION = "1.0.9171"
ELECTRON_VERSION = "34.5.1"
CHROME_VERSION_ELECTRON = "132"
DEFAULT_USER_AGENT = (
    f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    f"(KHTML, like Gecko) discord/{DISCORD_CLIENT_VERSION} "
    f"Chrome/{CHROME_VERSION_ELECTRON}.0.0.0 Electron/{ELECTRON_VERSION} Safari/537.36"
)
def fetch_build_number() -> int:
    try:
        resp = primp.Client(verify=False).get("https://discord.com/login", timeout=10)
        if resp.status_code != 200:
            return FALLBACK_BUILD_NUMBER
        asset_urls = re.findall(r'/assets/([a-zA-Z0-9_-]+)\.js', resp.text)
        if not asset_urls:
            return FALLBACK_BUILD_NUMBER
        for asset_hash in reversed(asset_urls):
            try:
                js_resp = primp.Client(verify=False).get(
                    f"https://discord.com/assets/{asset_hash}.js",
                    timeout=10
                )
                if js_resp.status_code != 200:
                    continue
                match = re.search(r'buildNumber["\s:,]+(\d{4,7})', js_resp.text)
                if match:
                    return int(match.group(1))
            except Exception:
                continue
        return FALLBACK_BUILD_NUMBER
    except Exception:
        return FALLBACK_BUILD_NUMBER
BUILD_NUMBER = fetch_build_number()
def _random_uuid() -> str:
    return f"{random.randint(10000000, 99999999)}-{random.randint(1000, 9999)}-{random.randint(1000, 9999)}-{random.randint(1000, 9999)}-{random.randint(100000000000, 999999999999)}"
def generate_super_properties(
    launch_id: str, signature: str, heartbeat_id: str, native_build: int
) -> str:
    return base64.b64encode(json.dumps({
        "os": "Windows",
        "browser": "Discord Client",
        "release_channel": "stable",
        "client_version": DISCORD_CLIENT_VERSION,
        "os_version": "10.0.26100",
        "os_arch": "x64",
        "app_arch": "x64",
        "system_locale": "en-US",
        "has_client_mods": False,
        "browser_user_agent": DEFAULT_USER_AGENT,
        "browser_version": ELECTRON_VERSION,
        "client_build_number": BUILD_NUMBER,
        "native_build_number": native_build,
        "client_event_source": None,
        "client_launch_id": launch_id,
        "launch_signature": signature,
        "client_heartbeat_session_id": heartbeat_id,
    }, separators=(",", ":")).encode()).decode()
hz_proxy_manager = None
print_lock = threading.Lock()
file_lock = threading.Lock()
def get_timestamp() -> str:
    return datetime.now().strftime("%H:%M:%S")
def log(log_type: str, token: str, message: str):
    timestamp = get_timestamp()
    masked = mask_token(token)
    with print_lock:
        ts = f"{Fore.LIGHTBLACK_EX}[{timestamp}]{Style.RESET_ALL}"
        tok = f"{Fore.LIGHTBLACK_EX}[{Style.RESET_ALL}Token : {Fore.CYAN}{masked}{Style.RESET_ALL}{Fore.LIGHTBLACK_EX}]{Style.RESET_ALL}"
        if log_type == "SUCCESS":
            status = f"{Fore.GREEN}[SUCCESS]{Style.RESET_ALL}"
        elif log_type == "FAILED":
            status = f"{Fore.RED}[FAILED]{Style.RESET_ALL}"
        elif log_type == "WARN":
            status = f"{Fore.YELLOW}[WARN]{Style.RESET_ALL}"
        elif log_type == "INFO":
            status = f"{Fore.CYAN}[INFO]{Style.RESET_ALL}"
        else:
            status = f"[{log_type}]"
        if " : " in message and message.startswith("[") and message.endswith("]"):
            inner = message[1:-1]
            parts = inner.split(" : ", 1)
            if len(parts) == 2:
                desc, value = parts
                msg = f"{Fore.LIGHTBLACK_EX}[{Style.RESET_ALL}{Fore.WHITE}{desc}{Style.RESET_ALL} : {Fore.CYAN}{value}{Style.RESET_ALL}{Fore.LIGHTBLACK_EX}]{Style.RESET_ALL}"
            else:
                msg = f"{Fore.LIGHTBLACK_EX}[{Style.RESET_ALL}{Fore.WHITE}{inner}{Style.RESET_ALL}{Fore.LIGHTBLACK_EX}]{Style.RESET_ALL}"
        else:
            msg = message
        print(f"{ts} - {status} - {tok} → {msg}")
def log_simple(log_type: str, message: str):
    timestamp = get_timestamp()
    ts = f"{Fore.LIGHTBLACK_EX}[{timestamp}]{Style.RESET_ALL}"
    with print_lock:
        if log_type == "FAILED":
            print(f"{ts} - {Fore.RED}[FAILED]{Style.RESET_ALL} - {Fore.RED}{message}{Style.RESET_ALL}")
        elif log_type == "INFO":
            print(f"{ts} - {Fore.CYAN}[INFO]{Style.RESET_ALL} - {Fore.WHITE}{message}{Style.RESET_ALL}")
        else:
            print(f"{ts} - {message}")
def mask_token(token: str) -> str:
    if len(token) <= 20:
        return token[:10] + "****"
    return token[:10] + "****" + token[-10:]
def load_file_lines(file_path: Path) -> List[str]:
    if not file_path.exists():
        return []
    with open(file_path, 'r', encoding='utf-8') as f:
        return [line.strip() for line in f if line.strip() and not line.strip().startswith('#')]
def append_to_file(file_path: Path, content: str):
    with file_lock:
        with open(file_path, 'a', encoding='utf-8') as f:
            f.write(content + '\n')
def remove_token_from_file(file_path: Path, token: str):
    with file_lock:
        try:
            lines = file_path.read_text(encoding='utf-8').splitlines()
            new_lines = [l for l in lines if extract_token(l) != token.strip()]
            file_path.write_text('\n'.join(new_lines) + ('\n' if new_lines else ''), encoding='utf-8')
        except Exception:
            pass 
def format_time(seconds: float) -> str:
    minutes = int(seconds // 60)
    hours = minutes // 60
    if hours > 0:
        return f"{hours}h {minutes % 60}m"
    if minutes > 0:
        secs = seconds % 60
        return f"{minutes}m {secs:.2f}s"
    return f"{seconds:.2f}s"
def is_valid_token(s: str) -> bool:
    if not s or len(s) < 50:
        return False
    parts = s.split('.')
    if len(parts) != 3:
        return False
    return all(re.match(r'^[A-Za-z0-9_-]+$', part) and len(part) > 0 for part in parts)
def extract_token(line: str) -> Optional[str]:
    line = line.strip()
    if not line:
        return None
    if is_valid_token(line):
        return line
    for delimiter in [':', '|', '\t', ' ']:
        if delimiter in line:
            parts = line.split(delimiter)
            for part in reversed(parts):
                part = part.strip()
                if is_valid_token(part):
                    return part
    return None
def load_tokens(file_path: Path) -> List[str]:
    lines = load_file_lines(file_path)
    tokens = []
    for line in lines:
        token = extract_token(line)
        if token:
            tokens.append(token)
    seen = set()
    deduped = []
    for t in tokens:
        if t not in seen:
            seen.add(t)
            deduped.append(t)
    return deduped
def load_avatar_files() -> List[Path]:
    if not AVATARS_DIR.exists():
        return []
    valid_extensions = {'.png', '.jpg', '.jpeg', '.gif', '.webp'}
    return [f for f in AVATARS_DIR.iterdir() if f.suffix.lower() in valid_extensions]
DISCORD_AVATAR_MAX_BYTES = 1_000_000  
def load_avatar_as_base64(image_path: Path) -> Optional[str]:
    try:
        with Image.open(image_path) as img:
            is_png = image_path.suffix.lower() == '.png'
            if is_png:
                if img.mode == 'P':
                    img = img.convert('RGBA')
            else:
                if img.mode in ('RGBA', 'P'):
                    img = img.convert('RGB')
            img = img.resize((AVATAR_DIMENSION, AVATAR_DIMENSION), Image.Resampling.LANCZOS)
            img_copy = img.copy()  
            def _encode(pil_img, fmt, quality=80) -> str:
                buf = BytesIO()
                kw = {"format": fmt}
                if fmt == "JPEG":
                    kw["quality"] = quality
                    kw["optimize"] = True
                pil_img.save(buf, **kw)
                buf.seek(0)
                return base64.b64encode(buf.read()).decode()
            img_format = 'PNG' if is_png else 'JPEG'
            b64 = _encode(img_copy, img_format)
            mime = 'image/png' if img_format == 'PNG' else 'image/jpeg'
            if len(b64) > DISCORD_AVATAR_MAX_BYTES:
                work_img = img_copy.convert('RGB') if img_copy.mode in ('RGBA', 'P', 'LA') else img_copy
                mime = 'image/jpeg'
                for quality in (80, 60, 40, 20):
                    b64 = _encode(work_img, 'JPEG', quality)
                    if len(b64) <= DISCORD_AVATAR_MAX_BYTES:
                        break
                else:
                    half = max(64, AVATAR_DIMENSION // 2)
                    work_img = work_img.resize((half, half), Image.Resampling.LANCZOS)
                    for quality in (80, 60, 40):
                        b64 = _encode(work_img, 'JPEG', quality)
                        if len(b64) <= DISCORD_AVATAR_MAX_BYTES:
                            break
                    else:
                        return None  
            return f"data:{mime};base64,{b64}"
    except Exception:
        return None
def parse_proxy(proxy_string: str) -> Optional[str]:
    proxy = proxy_string.strip()
    if proxy.startswith('#'):
        return None
    if '://' in proxy:
        parsed = urlparse(proxy)
        if parsed.hostname and parsed.port:
            return proxy
        return None
    if '@' in proxy:
        at_idx = proxy.rfind('@')
        auth = proxy[:at_idx]
        hostport = proxy[at_idx + 1:]
        colon_idx = auth.find(':')
        if colon_idx == -1:
            return None
        user = auth[:colon_idx]
        password = auth[colon_idx + 1:]
        host_parts = hostport.rsplit(':', 1)
        if len(host_parts) != 2:
            return None
        host, port = host_parts
        return f"http://{quote(user, safe='')}:{quote(password, safe='')}@{host}:{port}"
    parts = proxy.split(':')
    if len(parts) == 4:
        host, port, user, password = parts
        return f"http://{quote(user, safe='')}:{quote(password, safe='')}@{host}:{port}"
    elif len(parts) == 2:
        return f"http://{parts[0]}:{parts[1]}"
    return None
class Humanizer:
    def __init__(self, token: str, proxy: Optional[str] = None):
        self.token = token
        self.proxy = proxy
        self.client = primp.Client(
            verify=False,
            proxy=proxy if proxy else None
        )
        self.user_agent = DEFAULT_USER_AGENT
        self.session_id = None
        self.proxy_failed = False
        self.is_locked = False
        self.installation_id = f"{random.randint(10**18, 10**19 - 1)}.{''.join(random.choices('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_', k=22))}"
        self._launch_id = str(uuid.uuid4())
        self._signature = str(uuid.uuid4())
        self._heartbeat_id = str(uuid.uuid4())
        self._native_build = random.randint(65600, 65800)
        self._super_props = generate_super_properties(
            self._launch_id, self._signature, self._heartbeat_id, self._native_build
        )
    def get_fingerprint(self):
        try:
            r = self.client.get("https://discord.com/api/v9/experiments", timeout=30)
            if r.status_code == 200:
                return r.json().get("fingerprint")
        except:
            pass
        return None
    async def _send_identify(self, ws) -> bool:
        try:
            hello = json.loads(await asyncio.wait_for(ws.recv(), timeout=15))
            if hello.get("op") != 10:
                return False
            identify_payload = {
                "op": 2,
                "d": {
                    "token": self.token,
                    "capabilities": 16381,
                    "properties": {
                        "os": "Windows",
                        "browser": "Discord Client",
                        "release_channel": "stable",
                        "client_version": DISCORD_CLIENT_VERSION,
                        "os_version": "10.0.26100",
                        "os_arch": "x64",
                        "app_arch": "x64",
                        "system_locale": "en-US",
                        "browser_user_agent": self.user_agent,
                        "browser_version": ELECTRON_VERSION,
                        "os_sdk_version": "26100",
                        "client_build_number": BUILD_NUMBER,
                        "native_build_number": self._native_build,
                        "client_event_source": None,
                        "design_id": 0
                    },
                    "presence": {
                        "status": "online",
                        "since": 0,
                        "activities": [],
                        "afk": False
                    },
                    "compress": False,
                    "client_state": {
                        "guild_versions": {},
                        "highest_last_message_id": "0",
                        "read_state_version": 0,
                        "user_guild_settings_version": -1,
                        "user_settings_version": -1,
                        "private_channels_version": "0",
                        "api_code_version": 0
                    }
                }
            }
            await ws.send(json.dumps(identify_payload))
            return True
        except Exception:
            return False
    async def _wait_for_ready(self, ws) -> bool:
        for _ in range(12):     
            try:
                msg = json.loads(await asyncio.wait_for(ws.recv(), timeout=10))
                op = msg.get("op")
                t = msg.get("t")
                if op == 11 or (op == 0 and t != "READY"):
                    continue
                if t == "READY":
                    self.session_id = msg["d"].get("session_id")
                    return True
                if op == 9:
                    return False
            except asyncio.TimeoutError:
                break
        return False
    async def update_account_with_live_session(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        if getattr(self, "is_locked", False):
            return {"success": False, "error": "Token Locked"}
        headers = self.get_headers()
        loop = asyncio.get_event_loop()
        if "avatar" not in payload:
            direct = await loop.run_in_executor(None, lambda: self.update_user_profile(payload, headers))
            if direct.get("success") or direct.get("captcha") or direct.get("rate_limited"):
                return direct
            if not direct.get("unknown_session"):
                return direct
        async def _ws_patch(ws) -> Dict[str, Any]:
            if not await self._send_identify(ws):
                return {"success": False, "error": "Gateway IDENTIFY failed"}
            if not await self._wait_for_ready(ws):
                return {"success": False, "error": "Gateway READY timeout"}
            return await loop.run_in_executor(None, lambda: self.update_user_profile(payload, headers))
        try:
            extra_headers = {"User-Agent": self.user_agent}
            if self.proxy:
                proxy = Proxy.from_url(self.proxy)
                sock = await proxy.connect(dest_host="gateway.discord.gg", dest_port=443)
                async with websockets.connect(
                    DISCORD_GATEWAY,
                    additional_headers=extra_headers,
                    sock=sock,
                    server_hostname="gateway.discord.gg",
                    open_timeout=60,
                    close_timeout=10,
                    max_size=None   
                ) as ws:
                    return await _ws_patch(ws)
            else:
                async with websockets.connect(
                    DISCORD_GATEWAY,
                    additional_headers=extra_headers,
                    open_timeout=60,
                    close_timeout=10,
                    max_size=None   
                ) as ws:
                    return await _ws_patch(ws)
        except Exception as e:
            err_str = str(e)
            if not err_str:
                err_str = type(e).__name__
            if self.proxy and ("proxy" in err_str.lower() or "connect" in err_str.lower()):
                self.proxy_failed = True
            return {"success": False, "error": err_str}
    def update_account_sync(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        max_retries = 2
        last_error = None
        for attempt in range(max_retries):
            try:
                future = asyncio.run_coroutine_threadsafe(
                    self.update_account_with_live_session(payload), _async_loop
                )
                result = future.result()
                if result["success"]:
                    return result
                error = str(result.get("error", ""))
                if self._is_transient_error(error):
                    last_error = self._clean_error(error)
                    if proxy_manager and attempt < max_retries - 1:
                        new_proxy = proxy_manager.get_proxy()
                        if new_proxy:
                            self.proxy = new_proxy
                            self.client = primp.Client(verify=False, proxy=new_proxy)
                        continue
                return result
            except Exception as e:
                last_error = self._clean_error(str(e))
                if attempt < max_retries - 1 and proxy_manager:
                    new_proxy = proxy_manager.get_proxy()
                    if new_proxy:
                        self.proxy = new_proxy
                        self.client = primp.Client(verify=False, proxy=new_proxy)
                    continue
        return {"success": False, "error": last_error or "Max retries reached"}
    def _clean_error(self, error) -> str:
        error = str(error)
        if "RATE_LIMIT" in error or "rate limit" in error.lower() or "too often" in error.lower():
            return "Rate Limited"
        if "curl:" in error:
            if "(56)" in error:
                return "Proxy closed"
            elif "(28)" in error:
                return "Timeout"
            elif "(7)" in error:
                return "Proxy failed"
            else:
                match = re.search(r'curl: \((\d+)\)', error)
                if match:
                    return f"Curl {match.group(1)}"
        if "Unknown Session" in error:
            return "Bad session"
        if "received 4000" in error or "4000 (private" in error:
            return "Token locked / flagged (WS 4000)"
        if "received 4001" in error:
            return "Invalid token (WS 4001)"
        if "received 4004" in error:
            return "Auth failed (WS 4004)"
        if "received 4006" in error:
            return "Session invalid (WS 4006)"
        if "Unauthorized" in error or "401" in error:
            return "Unauthorized"
        if "captcha" in error.lower():
            return "Captcha"
        if "Invalid Form Body" in error:
            return "Invalid request"
        if "message" in error and "code" in error:
            match = re.search(r"'message': '([^']+)'", error)
            if match:
                msg = match.group(1)
                if len(msg) > 25:
                    return msg[:22] + "..."
                return msg
        if len(error) > 80:
            return error[:77] + "..."
        return error
    def get_headers(self) -> Dict[str, str]:
        headers = {
            "accept": "*/*",
            "accept-encoding": "gzip, deflate, br",
            "accept-language": "en-US",
            "authorization": self.token,
            "content-type": "application/json",
            "user-agent": self.user_agent,
            "x-debug-options": "bugReporterEnabled",
            "x-discord-locale": "en-US",
            "x-discord-timezone": "Asia/Calcutta",
            "x-installation-id": self.installation_id,
            "x-super-properties": self._super_props
        }
        fp = self.get_fingerprint()
        if fp:
            headers["x-fingerprint"] = fp
        return headers
    def _is_transient_error(self, error_str: str) -> bool:
        lower = error_str.lower()
        return any(kw in lower for kw in (
            "connection", "proxy", "timeout", "reset", "connect",
            "sending", "refused", "unreachable", "eof", "read error",
            "gateway ready", "gateway identify", "gateway",
            "no close frame", "connection closed", "websocket"
        ))
    def _api_call_with_retry(self, method: str, url: str, data: Dict[str, Any],
                              headers: Dict[str, str], max_retries: int = 5) -> Dict[str, Any]:
        if getattr(self, "is_locked", False):
            return {"success": False, "error": "Token Locked"}
        last_result = None
        for attempt in range(max_retries):
            if getattr(self, "is_locked", False):
                return {"success": False, "error": "Token Locked"}
            try:
                if method.upper() == "POST":
                    resp = self.client.post(url, headers=headers, json=data, timeout=60)
                else:
                    resp = self.client.patch(url, headers=headers, json=data, timeout=60)
                if resp.status_code in (200, 204):
                    try:
                        data = resp.json() if resp.text and resp.status_code == 200 else {}
                    except Exception:
                        data = {}
                    return {"success": True, "data": data}
                try:
                    error_data = resp.json() if resp.text and resp.text.strip() else {}
                except Exception:
                    error_data = {}
                if error_data.get("captcha_key"):
                    return {"success": False, "captcha": True, "error": error_data}
                if resp.status_code == 400 and isinstance(error_data, dict):
                    code = error_data.get("code")
                    if code == 10020:
                        return {"success": False, "unknown_session": True, "error": "Unknown Session"}
                    errors = error_data.get("errors", {})
                    for field_errors in errors.values():
                        for err in field_errors.get("_errors", []):
                            if err.get("code") == "AVATAR_RATE_LIMIT":
                                return {"success": False, "rate_limited": True, "retry_after": 0, "error": "Avatar Rate Limited"}
                if resp.status_code == 429:
                    try:
                        ra_header = resp.headers.get("retry-after") or resp.headers.get("Retry-After")
                        ra_body = error_data.get("retry_after", 0) if isinstance(error_data, dict) else 0
                        retry_after = float(ra_header) if ra_header else float(ra_body or 0)
                    except (TypeError, ValueError):
                        retry_after = 0
                    wait_time = max(retry_after, 1.0)
                    time.sleep(wait_time)
                    continue  
                last_result = {"success": False, "error": error_data}
                if resp.status_code in (401, 403):
                    self.is_locked = True
                    return last_result
            except Exception as e:
                error_str = str(e)
                last_result = {"success": False, "error": error_str}
                if self.proxy and self._is_transient_error(error_str):
                    self.proxy_failed = True
                if self._is_transient_error(error_str) and proxy_manager and attempt < max_retries - 1:
                    new_proxy = proxy_manager.get_proxy()
                    if new_proxy:
                        self.proxy = new_proxy
                        self.client = primp.Client(verify=False, proxy=new_proxy)
                    continue
                if attempt >= max_retries - 1:
                    return last_result
        return last_result or {"success": False, "error": "Max retries reached"}
    def update_user_profile(self, data: Dict[str, Any], headers: Dict[str, str]) -> Dict[str, Any]:
        return self._api_call_with_retry("patch", f"{DISCORD_API}/users/@me", data, headers)
    def update_profile_fields(self, data: Dict[str, Any], headers: Dict[str, str]) -> Dict[str, Any]:
        return self._api_call_with_retry("patch", f"{DISCORD_API}/users/@me/profile", data, headers)
    def set_hypesquad(self, house_id: int, headers: Dict[str, str], retry_count: int = 0) -> Dict[str, Any]:
        time.sleep(random.uniform(2, 5))
        house_name = HYPESQUAD_HOUSES.get(house_id, "Unknown")
        try:
            check = self.client.get(
                f"{DISCORD_API}/users/@me",
                headers=headers,
                timeout=30
            )
            if check.status_code == 200:
                data = check.json()
                flags = data.get("flags", 0)
                if flags & 0xE:
                    existing_house = None
                    for hid, hname in HYPESQUAD_HOUSES.items():
                        if flags & (1 << hid):
                            existing_house = hname
                            break
                    if existing_house:
                        log("INFO", self.token, f"[HypeSquad Already Set : {existing_house}]")
                        return {"success": True, "house_name": existing_house, "already_set": True}
        except Exception:
            pass
        res = self._api_call_with_retry(
            "post",
            f"{DISCORD_API}/hypesquad/online",
            {"house_id": house_id},
            headers,
            max_retries=2
        )
        if res.get("success"):
            return {"success": True, "house_name": house_name}
        if retry_count < RETRY_LIMIT:
            log("WARN", self.token, f"[HypeSquad Retry : {retry_count + 1}/{RETRY_LIMIT} for {house_name}]")
            time.sleep(random.uniform(2.0, 4.0))
            return self.set_hypesquad(house_id, headers, retry_count + 1)
        return {"success": False, "error": f"HypeSquad {house_name} not applied - Account may already have a badge or is rate limited", "house_name": house_name}
    def process(self, names: List[str], bios: List[str], pronouns_list: List[str],
                avatar_files: List[Path], avatar_loader) -> bool:
        headers = self.get_headers()
        success = True
        parallel_tasks = []
        account_payload = {}
        avatar_name = None
        if UPDATE_AVATAR and avatar_files:
            avatar_path = random.choice(avatar_files)
            avatar_b64 = avatar_loader(avatar_path)
            if avatar_b64:
                account_payload["avatar"] = avatar_b64
                av_hash = hashlib.md5(avatar_b64[:100].encode()).hexdigest()
                now = datetime.now()
                now_str = now.strftime("%B {d}, %Y at {t}").format(
                    d=now.day,
                    t=now.strftime("%I:%M %p").lstrip("0")
                )
                account_payload["avatar_description"] = f"{av_hash}, added {now_str}"
                avatar_name = avatar_path.name
        display_name = None
        if UPDATE_DISPLAY_NAME and names:
            display_name = random.choice(names)
            account_payload["global_name"] = display_name
        if account_payload:
            parallel_tasks.append(("account", (account_payload, avatar_name, display_name)))
        profile_payload = {}
        bio = None
        if UPDATE_BIO and bios:
            bio = random.choice(bios)
            profile_payload["bio"] = bio
        pronouns = None
        if UPDATE_PRONOUNS and pronouns_list:
            pronouns = random.choice(pronouns_list)
            profile_payload["pronouns"] = pronouns
        if profile_payload:
            parallel_tasks.append(("profile", (profile_payload, bio, pronouns)))
        house_id = None
        house_name = None
        if UPDATE_HYPESQUAD:
            time.sleep(random.uniform(0, 3))
            house_id = random.choice([1, 2, 3])
            house_name = HYPESQUAD_HOUSES[house_id]
            parallel_tasks.append(("hypesquad", (house_id, house_name)))
        if parallel_tasks:
            def _run_field(task_type, value):
                if getattr(self, "is_locked", False):
                    return (task_type, {"success": False, "error": "Token Locked"}, value)
                h = headers.copy()
                if task_type == "account":
                    payload, _, _ = value
                    if "avatar" in payload:
                        return ("account", self.update_account_sync(payload), value)
                    else:
                        return ("account", self.update_user_profile(payload, h), value)
                elif task_type == "profile":
                    payload, _, _ = value
                    return ("profile", self.update_profile_fields(payload, h), value)
                elif task_type == "hypesquad":
                    hid, _ = value
                    return ("hypesquad", self.set_hypesquad(hid, h), value)
                return ("unknown", {"success": False, "error": "Unknown field type"}, value)
            with ThreadPoolExecutor(max_workers=len(parallel_tasks)) as field_executor:
                futures = [field_executor.submit(_run_field, tt, val) for tt, val in parallel_tasks]
                for future in as_completed(futures):
                    try:
                        task_type, result, values = future.result()
                    except Exception as e:
                        log("FAILED", self.token, f"[Field Error : {str(e)[:30]}]")
                        success = False
                        continue
                    if task_type == "account":
                        _, aname, dname = values
                        if result["success"]:
                            pass
                        elif result.get("captcha"):
                            if aname: log("WARN", self.token, "[Avatar Failed : Captcha]")
                            if dname: log("WARN", self.token, "[Name Failed : Captcha]")
                            success = False
                        elif result.get("rate_limited"):
                            ra = result.get("retry_after", 0)
                            ra_str = f"{int(ra)}s" if ra else "unknown"
                            if aname: log("WARN", self.token, f"[Avatar Failed : Rate Limited ({ra_str})]")
                            if dname: log("WARN", self.token, f"[Name Failed : Rate Limited ({ra_str})]")
                            success = False
                        else:
                            error_msg = self._clean_error(result.get("error", "Unknown"))
                            if aname: log("FAILED", self.token, f"[Avatar Failed : {error_msg}]")
                            if dname: log("FAILED", self.token, f"[Name Failed : {error_msg}]")
                            success = False
                    elif task_type == "profile":
                        _, bname, pname = values
                        if result["success"]:
                            pass
                        elif result.get("captcha"):
                            if bname: log("WARN", self.token, "[Bio Failed : Captcha]")
                            if pname: log("WARN", self.token, "[Pronouns Failed : Captcha]")
                            success = False
                        else:
                            error_msg = self._clean_error(result.get("error", "Unknown"))
                            if bname: log("FAILED", self.token, f"[Bio Failed : {error_msg}]")
                            if pname: log("FAILED", self.token, f"[Pronouns Failed : {error_msg}]")
                            success = False
                    elif task_type == "hypesquad":
                        _, hsname = values
                        if result.get("success"):
                            applied_house = result.get("house_name", hsname)
                        else:
                            error_msg = self._clean_error(result.get("error", "Unknown"))
                            log("FAILED", self.token, f"[HypeSquad Failed : {hsname} - {error_msg}]")
                            success = False
        if self.proxy_failed and proxy_manager:
            proxy_manager.mark_bad(self.proxy)
        return success
def process_token(token: str, names: List[str], bios: List[str], pronouns_list: List[str],
                  avatar_files: List[Path], avatar_loader) -> bool:
    proxy = proxy_manager.get_proxy() if proxy_manager else None
    humanizer = Humanizer(token, proxy)
    try:
        return humanizer.process(names, bios, pronouns_list, avatar_files, avatar_loader)
    finally:
        if proxy_manager and proxy:
            proxy_manager.release_proxy(proxy)
def stats_updater():
    while True:
        time.sleep(2)
        with stats_lock:
            total = stats['total']
            gen = stats['generated']
            ver = stats['verified']
            cap_fail = stats['captcha_failed']
            cap_solved = stats['captcha_solved']
            locked = stats['locked']
            valid = stats['valid']
        gen_pct = (gen / total * 100) if total else 0
        ver_pct = (ver / total * 100) if total else 0
        cap_fail_pct = (cap_fail / total * 100) if total else 0
        cap_solved_pct = (cap_solved / total * 100) if total else 0
        locked_pct = (locked / total * 100) if total else 0
        valid_pct = (valid / total * 100) if total else 0
        current_time = datetime.now().strftime('%H:%M')
        title = f"{current_time} [STATS] Gen: {gen} ({gen_pct:.1f}%) | EV: {ver} ({ver_pct:.1f}%) | CapFail: {cap_fail} ({cap_fail_pct:.1f}%) | Solved: {cap_solved} ({cap_solved_pct:.1f}%) | Locked: {locked} ({locked_pct:.1f}%) | Invalid: {valid} ({valid_pct:.1f}%) | Total: {total}"
        ctypes.windll.kernel32.SetConsoleTitleW(title)
P = "\033[38;2;121;3;255m"     
C = "\033[38;2;3;248;252m"     
G = "\033[38;2;68;255;0m"      
D = "\033[38;2;92;94;91m"      
R = "\033[0m"                  
def display_banner():
    if os.name == "nt":
        os.system("")
    os.system("cls" if os.name == "nt" else "clear")
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    print(f"""
  {P}┌───────────────────────────────────────────────┐
  │                                               │
  │   █████╗ ██████╗ ███████╗██╗   ██╗███████╗    │
  │  ██╔══██╗██╔══██╗██╔════╝██║   ██║██╔════╝    │
  │  ╚██████║██║  ██║█████╗  ██║   ██║███████╗    │
  │   ╚═══██║██║  ██║██╔══╝  ╚██╗ ██╔╝╚════██║    │
  │   █████╔╝██████╔╝███████╗ ╚████╔╝ ███████║    │
  │   ╚════╝ ╚═════╝ ╚══════╝  ╚═══╝  ╚══════╝    │
  │                                               │
  │  {D}9DEVS v1.0{P}                                   │
  │  {D}Fast · Stealth · Reliable{P}                    │
  │                                               │
  └───────────────────────────────────────────────┘{R}
""")
if __name__ == "__main__":
    display_banner()
    cap_cfg = config.get("9captcha", {})
    ext_mode = cap_cfg.get("extension_solver", True)
    vps_mode = cap_cfg.get("req_solver", False)
    mode_str = []
    if ext_mode: mode_str.append("Extension")
    if vps_mode: mode_str.append("Request")
    print(f"  {D}│{R} {D}Solver:{R} {G}{' + '.join(mode_str) if mode_str else 'None!'}{R}")
    if ext_mode:
        try:
            from engine.extension_browser import get_browser, sync_api_key
            print(f"  {D}│{R} {C}Validating 9Captcha API Key...{R}")
            api_key_valid = sync_api_key()
            if not api_key_valid:
                print(f"  {D}│{R} {Fore.RED}⚠ FATAL: Invalid 9Captcha API Key. Generator explicitly aborted!{R}")
                sys.exit(1)
            print(f"  {D}│{R} {C}Initializing extension browser...{R}")
            print(f"  {D}│{R} {G}✓ Extension browser ready{R}")
        except SystemExit:
            raise
        except ImportError as e:
            print(f"  {D}│{R} {Fore.YELLOW}⚠ Extension browser unavailable: {e}{R}")
            print(f"  {D}│{R} {D}  pip install truedriver{R}")
            
        import atexit
        def cleanup_browser():
            try: get_browser().stop()
            except: pass
        atexit.register(cleanup_browser)

    if vps_mode:
        p_path = Path("input/proxies.txt")
        if not p_path.exists() or len(load_file_lines(p_path)) == 0:
            print(f"  {D}│{R} {Fore.RED}⚠ FATAL: Req Solver ONLY works with proxies!{R}")
            print(f"  {D}│{R} {Fore.YELLOW}If you don't have proxies, please enable the Extension Solver instead in settings.{R}")
            sys.exit(1)
            
    print()
    NUM_THREADS = int(config.get("threads", 1))
    semaphore = threading.Semaphore(NUM_THREADS)
    stats_thread = threading.Thread(target=stats_updater, daemon=True)
    stats_thread.start()
    def worker(current_num):
        proxy = proxy_manager.pop_top()
        email = mail_api.create_account()
        if not email:
            Log.error("emails are not available")
            semaphore.release()
            return
        username = _random_username()
        password = _random_password()
        try:
            generate_9DEVS_token(email, username, password, proxy, current_num)
        finally:
            semaphore.release()
    while True:
        semaphore.acquire()
        with gen_lock:
            gen_count += 1
            current_num = gen_count
        t = threading.Thread(target=worker, args=(current_num,), daemon=True)
        t.start()
